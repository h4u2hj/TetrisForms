﻿namespace TetrisModel
{
    internal class Program
    {
        static void Main()
        {

        }
    }
}
